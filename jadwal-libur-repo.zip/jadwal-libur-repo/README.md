# Jadwal Libur Bersama

Kalender bersama untuk memilih tanggal libur dalam sebulan supaya tidak bentrok dengan teman. Data disimpan di Google Sheet, websitenya satu file HTML biasa.

## Fitur

- Kalender bulanan, semua orang melihat siapa saja yang libur di tiap tanggal.
- Batas orang libur per hari, supaya tanggal yang sudah penuh tidak bisa dipilih lagi.
- Jatah libur per orang per bulan.
- Orang hanya bisa membatalkan libur miliknya sendiri.
- Tampil rapi di HP, mendukung mode terang dan gelap.
- Data tersimpan di Google Sheet milikmu, tanpa server tambahan.

## Isi repository

```
index.html          Website (HTML, CSS, JS dalam satu file)
apps-script/Code.gs Backend Google Apps Script yang membaca dan menulis Google Sheet
```

## Cara memasang

### 1. Siapkan Google Sheet dan backend

1. Buka https://sheets.new lalu beri nama, misalnya "Jadwal Libur".
2. Klik **Extensions > Apps Script**.
3. Hapus isi editor, tempel seluruh isi `apps-script/Code.gs`, lalu klik **Save**.
4. Klik **Deploy > New deployment**, pilih jenis **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**
5. Klik **Deploy**, izinkan akses saat diminta, lalu salin **Web app URL** (berakhiran `/exec`).

Sheet `Libur` dan `Pengaturan` dibuat otomatis saat website pertama kali dibuka.

### 2. Hubungkan website ke Sheet

Di `index.html`, cari baris ini di bagian `<script>`:

```js
const API_URL = "";
```

Isi dengan URL tadi:

```js
const API_URL = "https://script.google.com/macros/s/XXXXXXXX/exec";
```

### 3. Online-kan dengan GitHub Pages

1. Di repository ini buka **Settings > Pages**.
2. Pada **Build and deployment**, pilih **Deploy from a branch**.
3. Pilih branch `main` dan folder `/ (root)`, lalu **Save**.
4. Tunggu satu sampai dua menit. Alamat websitenya muncul di halaman yang sama, biasanya `https://USERNAME.github.io/NAMA-REPO/`.

Bagikan alamat itu ke teman-teman.

## Mengatur aturan

Buka sheet `Pengaturan`, ubah angka di baris 2:

| batas_per_hari | batas_per_bulan |
|---|---|
| 2 | 4 |

- `batas_per_hari`: maksimal orang yang boleh libur di tanggal yang sama.
- `batas_per_bulan`: jatah libur tiap orang dalam satu bulan.

## Mencoba tanpa Google Sheet

Selama `API_URL` masih kosong, website berjalan dalam mode contoh dengan data tiruan yang hanya tersimpan di browser. Buka `index.html` langsung di browser untuk mencobanya.

## Catatan

- Pembatalan libur memakai token yang disimpan di browser saat memilih tanggal. Kalau data browser terhapus, hapus barisnya langsung di sheet `Libur`.
- Setelah mengubah `Code.gs`, pilih **Deploy > Manage deployments > Edit > New version** supaya perubahan berlaku.
- Kolom `token` di sheet `Libur` tidak pernah dikirim ke website. Jangan bagikan akses edit Sheet ke sembarang orang.
